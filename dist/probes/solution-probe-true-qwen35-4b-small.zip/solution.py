"""Leaderboard probe: True only for Qwen/Qwen3.5-4B."""

ROBUST_MODELS = ['Qwen/Qwen3.5-4B']


def are_robust(model_id, problems, reasoning_effort="default"):
    return [model_id in ROBUST_MODELS] * len(problems)
