"""Leaderboard probe: True only for deepseek-ai/DeepSeek-R1-0528-Qwen3-8B."""

ROBUST_MODELS = ['deepseek-ai/DeepSeek-R1-0528-Qwen3-8B']


def are_robust(model_id, problems, reasoning_effort="default"):
    return [model_id in ROBUST_MODELS] * len(problems)
