"""E27: problem length alone, fitted on official labels, for every model

`e27_model.joblib` was fitted by `submission/make_e27.py` on the 33 labelled problems of
`aimo-interp/train-main-v2`, labels pooled across configurations (robustness is a property of
the problem: PROGRESS Finding 38).
"""

import functools
from pathlib import Path

import joblib
import e27_features  # noqa: F401  (the pickled model references it)

MODEL_PATH = Path(__file__).resolve().parent / "e27_model.joblib"
DEEPSEEK = "deepseek-ai/DeepSeek-R1-0528-Qwen3-8B"


@functools.cache
def model():
    return joblib.load(MODEL_PATH)


def are_robust(model_id, problems, reasoning_effort="default"):
    probabilities = model().predict_proba(list(problems))[:, 1]
    return [bool(p >= 0.5) for p in probabilities]
