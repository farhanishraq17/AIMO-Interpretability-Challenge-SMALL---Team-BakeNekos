"""Leaderboard probe: True only for Skywork/Skywork-OR1-Math-7B."""

ROBUST_MODELS = ['Skywork/Skywork-OR1-Math-7B']


def are_robust(model_id, problems, reasoning_effort="default"):
    return [model_id in ROBUST_MODELS] * len(problems)
