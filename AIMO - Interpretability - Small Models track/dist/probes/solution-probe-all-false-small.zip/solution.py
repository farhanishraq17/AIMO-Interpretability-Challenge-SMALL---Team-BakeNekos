"""Leaderboard probe: every case predicted False."""

ROBUST_MODELS = []


def are_robust(model_id, problems, reasoning_effort="default"):
    return [model_id in ROBUST_MODELS] * len(problems)
