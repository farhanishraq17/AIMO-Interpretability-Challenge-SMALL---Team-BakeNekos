"""Leaderboard probe: True only for allenai/Olmo-3-7B-Think."""

ROBUST_MODELS = ['allenai/Olmo-3-7B-Think']


def are_robust(model_id, problems, reasoning_effort="default"):
    return [model_id in ROBUST_MODELS] * len(problems)
