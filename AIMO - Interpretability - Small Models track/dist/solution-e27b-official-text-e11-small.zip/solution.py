"""E27: char tf-idf on official labels; E11's text + hidden-state fusion for DeepSeek

`e27_model.joblib` was fitted by `submission/make_e27.py` on the 33 labelled problems of
`aimo-interp/train-main-v2`, labels pooled across configurations (robustness is a property of
the problem: PROGRESS Finding 38).
"""

import functools
from pathlib import Path

import joblib
from e11_inference import predict_robustness

MODEL_PATH = Path(__file__).resolve().parent / "e27_model.joblib"
DEEPSEEK = "deepseek-ai/DeepSeek-R1-0528-Qwen3-8B"


@functools.cache
def model():
    return joblib.load(MODEL_PATH)


def are_robust(model_id, problems, reasoning_effort="default"):
    if model_id == DEEPSEEK:
        return predict_robustness(model_id, problems)
    probabilities = model().predict_proba(list(problems))[:, 1]
    return [bool(p >= 0.5) for p in probabilities]
